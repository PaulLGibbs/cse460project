//touch.c
#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

char buf[512];

int
main(int argc, char *argv[])
{
  int file;

  if(argc < 2)
  {
    printf(1, "touch File1 File2 File3...");
    exit();
  }
  
  int i=0; 
      
  for (i = 1; i < argc; i++) 
  { 
    if((file = open(argv[i], O_RDONLY | O_CREATE )) < 0)
    {
      printf(1, "touch: cannot create %s\n", argv[1]);
      exit();
    }
    close(file);  
  } 
  exit();
}
